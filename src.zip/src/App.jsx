import { Play, Dumbbell, PlayCircle, Download, Trophy, Mic2, GraduationCap, Mail, MapPin, Instagram, Linkedin } from 'lucide-react'
import { motion } from 'framer-motion'
import { siteData } from './data/siteData.js'

function Header() {
  return (
    <header className="header">
      <a className="brand" href="#home"><span>AD</span> Alvin Delve</a>
      <nav>
        <a href="#broadcasting">Broadcasting</a>
        <a href="#about">About</a>
        <a href="#resume">Resume</a>
        <a href="#fitness">DelveFitness</a>
        <a href="#contact">Contact</a>
      </nav>
    </header>
  )
}

function Hero() {
  return (
    <section id="home" className="hero">
      <div className="heroPhoto"><div>Add ESPN / courtside hero photo</div></div>
      <motion.div className="heroText" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .8 }}>
        <p className="eyebrow">{siteData.title}</p>
        <h1>{siteData.name}</h1>
        <h2>{siteData.subtitle}</h2>
        <p>Broadcast voice. Athlete mindset. Professional standard. Bringing energy, insight, preparation, and authenticity to every game.</p>
        <div className="buttonRow">
          <a className="btn gold" href={siteData.reelUrl}><Play size={18} /> Watch My Reel</a>
          <a className="btn outline" href={siteData.bookingUrl}><Dumbbell size={18} /> Book Training</a>
        </div>
      </motion.div>
      <div className="espn">ESPN+</div>
    </section>
  )
}

function Highlights() {
  return (
    <section id="broadcasting" className="section black">
      <p className="eyebrow center">Broadcasting</p>
      <h2 className="sectionTitle center">Featured Highlights</h2>
      <p className="sectionIntro center">A quick portfolio for producers, SIDs, athletic directors, and conferences.</p>
      <div className="highlightGrid">
        {siteData.highlights.map((item) => (
          <a className="highlightCard" href={item.url} key={item.sport}>
            <div className="thumb"><PlayCircle size={46} /></div>
            <h3>{item.sport}</h3>
            <p>{item.label}</p>
          </a>
        ))}
      </div>
    </section>
  )
}

function About() {
  return (
    <section id="about" className="section about">
      <div className="portraitBlock">
        <div className="portraitPlaceholder">Add professional headshot</div>
        <p className="signature">Alvin Delve</p>
      </div>
      <div>
        <p className="eyebrow">About Alvin</p>
        <h2 className="sectionTitle">A passion for sports. A purpose beyond the game.</h2>
        <p className="bodyCopy">Alvin Delve is a multi-sport broadcast analyst with ESPN+ experience covering college athletics. A former Division I football athlete, Alvin brings a player’s lens, preparation, and competitive feel to every broadcast.</p>
        <p className="bodyCopy">His work blends storytelling, tactical understanding, and high-energy analysis designed to help viewers understand not just what happened, but why it mattered.</p>
      </div>
    </section>
  )
}

function Resume() {
  return (
    <section id="resume" className="section resume">
      <p className="eyebrow center">Resume</p>
      <h2 className="sectionTitle center">Broadcasting Experience</h2>
      <div className="resumeGrid">
        <div className="resumeCard"><Mic2 /><h3>ESPN+ Analyst</h3><p>College basketball, volleyball, baseball, softball, and track & field coverage.</p></div>
        <div className="resumeCard"><Trophy /><h3>Former D1 Athlete</h3><p>Idaho State football background adds player-level perspective to the booth.</p></div>
        <div className="resumeCard"><GraduationCap /><h3>Sports Storyteller</h3><p>Prepared, energetic, and focused on making the viewer smarter.</p></div>
      </div>
      <div className="center"><a className="btn outline" href={siteData.resumeUrl}><Download size={18} /> Download Resume</a></div>
    </section>
  )
}

function Fitness() {
  return (
    <section id="fitness" className="section fitness">
      <div>
        <p className="eyebrow">DelveFitness</p>
        <h2 className="sectionTitle">Train your body. Elevate your life.</h2>
        <p className="bodyCopy dark">DelveFitness is more than a workout — it’s a lifestyle. Personal training, online coaching, and stretch therapy designed to help clients look good, feel good, and perform at their best.</p>
        <a className="btn gold" href={siteData.bookingUrl}>Book Training</a>
      </div>
      <div className="fitnessPhoto">Add training photo</div>
      <div className="serviceList">
        {siteData.services.map((service) => (
          <div key={service.title}><h3>{service.title}</h3><p>{service.text}</p></div>
        ))}
      </div>
    </section>
  )
}

function Media() {
  return (
    <section id="media" className="section media">
      <p className="eyebrow center">Media</p>
      <h2 className="sectionTitle center">Gallery & Clips</h2>
      <div className="mediaGrid">
        <div>Add broadcast photo</div><div>Add courtside photo</div><div>Add training photo</div><div>Add reel clip</div>
      </div>
    </section>
  )
}

function Contact() {
  return (
    <section id="contact" className="cta">
      <div>
        <p className="eyebrow">Contact</p>
        <h2>Ready to take the next step?</h2>
        <p>Reach out for broadcasting, speaking, training, or partnership opportunities.</p>
      </div>
      <div className="contactLinks">
        <a href={`mailto:${siteData.email}`}><Mail size={18} /> {siteData.email}</a>
        <span><MapPin size={18} /> {siteData.location}</span>
        <a href={siteData.instagram}><Instagram size={18} /> Instagram</a>
        <a href={siteData.linkedin}><Linkedin size={18} /> LinkedIn</a>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="footer">
      <div className="footerLogo">AD</div>
      <p>ESPN+ College Sports Analyst • Founder of DelveFitness</p>
      <p>© 2026 Alvin Delve. All rights reserved.</p>
    </footer>
  )
}

export default function App() {
  return <><Header /><main><Hero /><Highlights /><About /><Resume /><Fitness /><Media /><Contact /></main><Footer /></>
}
